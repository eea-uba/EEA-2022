set.seed(456789)
u1<-rnorm(50)
u2<-rnorm(50)
u3<-rnorm(50)
u4<-rnorm(50)
error<-rnorm(50)
error2<-rnorm(50,sd=0.1)

x1<-u1
x2<-u2
aa<-c(1,2,3,0)
bb<-c(-1,2,0.5,3)

dd<-c(3,4,5,6)
x3<-aa[1]*u1+aa[2]*u2+error2
x4<-bb[1]*u1+bb[2]*u2+bb[3]*u3+bb[4]*u4
x5<-u1 + 4*u2
y<-dd[1]*x1+dd[2]*x2+dd[3]*x3+dd[4]*x4+error/0.1

cor(cbind(x1,x2,x3,x4,x5,y))

modelo1<-lm(y ~ x1+x2+x5)
summary(modelo1)
X<-model.matrix(modelo1)
dim(X)   #dimension de la matriz
qr(X)$rank #rango, es decir, numero de columnas lin indep
eigen(t(X)%*%X)$values #calculamos los autovalores de t(X)*X

modelo2<-lm(x3 ~ x1+x2)
summary(modelo2)

modelo2bis<-lm(x4 ~ x1+x2)
summary(modelo2bis)

ajusA<-lm(y ~ x1+x2+x3+x4)
summary(ajusA)


library(rms)  #for vif
vif(ajusA)
equis<-model.matrix(ajusA)
eigen(t(equis)%*%equis)$values
#numero de condicion 
eigen(t(equis)%*%equis)$values[1]/eigen(t(equis)%*%equis)$values[5]
qr(equis)$rank    


ajusB<-lm(y ~ x1+x2+x4)
summary(ajusB)
vif(ajusB)
equisB<-model.matrix(ajusB)
eigen(t(equisB)%*%equisB)$values
#numero de condicion 
eigen(t(equisB)%*%equisB)$values[1]/eigen(t(equisB)%*%equisB)$values[4]
#muuuucho mejor que A

predichosA<-predict(ajusA)
sum((predichosA-y)^2)


predichosB<-predict(ajusB)
sum((predichosB-y)^2)


#predice mejor el modelo de multicolinealidad en el mismo conjunto de datos
#en uno nuevo?

set.seed(123456)
sumaA<-rep(0,1000)
sumaB<-rep(0,1000)

for(i in 1:1000){
u1<-rnorm(50)
u2<-rnorm(50)
u3<-rnorm(50)
u4<-rnorm(50)
error<-rnorm(50)
error2<-rnorm(50,sd=0.1)

x1<-u1
x2<-u2
aa<-c(1,2,3,0)
bb<-c(-1,2,0.5,3)

dd<-c(3,4,5,6)
x3<-aa[1]*u1+aa[2]*u2+error2
x4<-bb[1]*u1+bb[2]*u2+bb[3]*u3+bb[4]*u4
y<-dd[1]*x1+dd[2]*x2+dd[3]*x3+dd[4]*x4+error/0.1


predichosA<-predict(ajus,newdata = data.frame(x1=x1,x2=x2,x3=x3,x4=x4))
sumaA[i]<-sum((predichosA-y)^2)


predichosB<-predict(ajusmejor,newdata = data.frame(x1=x1,x2=x2,x3=x3,x4=x4))
sumaB[i]<-sum((predichosB-y)^2)
}

boxplot(sumaA, sumaB)
sum(sumaA>sumaB)

#################################

coef.beta1A<-rep(0,1000)
coef.beta2A<-rep(0,1000)
coef.beta3A<-rep(0,1000)
coef.beta4A<-rep(0,1000)
coef.beta1B<-rep(0,1000)
coef.beta2B<-rep(0,1000)
coef.beta4B<-rep(0,1000)

pval.beta1A<-rep(0,1000)
pval.beta2A<-rep(0,1000)
pval.beta3A<-rep(0,1000)
pval.beta4A<-rep(0,1000)
pval.beta1B<-rep(0,1000)
pval.beta2B<-rep(0,1000)
pval.beta4B<-rep(0,1000)

set.seed(123456)
for(i in 1:1000){
  u1<-rnorm(50)
  u2<-rnorm(50)
  u3<-rnorm(50)
  u4<-rnorm(50)
  error<-rnorm(50)
  error2<-rnorm(50,sd=0.1)
  
  x1<-u1
  x2<-u2
  aa<-c(1,2,3,0)
  bb<-c(-1,2,0.5,3)
  
  dd<-c(3,4,5,6)
  x3<-aa[1]*u1+aa[2]*u2+error2
  x4<-bb[1]*u1+bb[2]*u2+bb[3]*u3+bb[4]*u4
  y<-dd[1]*x1+dd[2]*x2+dd[3]*x3+dd[4]*x4+error/0.1
  
  # ajustamos ambos modelo con los nuevos datos
  # y guardamos sus coeficientes estimados y
  # los p-valores obtenidos
  modeloA<-lm(y ~ x1+x2+x3+x4)
  coef.beta1A[i]<-as.numeric(coef(modeloA)[2])
  coef.beta2A[i]<-as.numeric(coef(modeloA)[3])
  coef.beta3A[i]<-as.numeric(coef(modeloA)[4])
  coef.beta4A[i]<-as.numeric(coef(modeloA)[5])
  #pvalores
  pval.beta1A[i]<-summary(modeloA)$coefficients[2,4] 
  pval.beta2A[i]<-summary(modeloA)$coefficients[3,4]
  pval.beta3A[i]<-summary(modeloA)$coefficients[4,4]
  pval.beta4A[i]<-summary(modeloA)$coefficients[5,4]

  modeloB<-lm(y ~ x1+x2+x4)
  coef.beta1B[i]<-as.numeric(coef(modeloB)[2])
  coef.beta2B[i]<-as.numeric(coef(modeloB)[3])
  coef.beta4B[i]<-as.numeric(coef(modeloB)[4])
  pval.beta1B[i]<-summary(modeloB)$coefficients[2,4]
  pval.beta2B[i]<-summary(modeloB)$coefficients[3,4]
  pval.beta4B[i]<-summary(modeloB)$coefficients[4,4]
  
}

boxplot(coef.beta1A,coef.beta1B)
boxplot(coef.beta2A,coef.beta2B)
boxplot(coef.beta4A,coef.beta4B)

var(coef.beta1A)
var(coef.beta1B)

var(coef.beta2A)
var(coef.beta2B)

var(coef.beta4A)
var(coef.beta4B)

sum(pval.beta1A<0.05)
sum(pval.beta1B<0.05)

sum(pval.beta2A<0.05)
sum(pval.beta2B<0.05)

sum(pval.beta4A<0.05)
sum(pval.beta4B<0.05)


#son mucho mas variables los estimadores de beta1 y beta2 bajo
#el modeloA que bajo el modeloB. Ambos modelos tienen performances
#comparables a la hora de predecir
